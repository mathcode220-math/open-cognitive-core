# open-cognitive-core Fixes

This archive contains the modified files for the `open-cognitive-core` repository.
All paths match the repo layout, so you can extract directly over your clone.

## Modified files
- `rtl/top/open_cognitive_top.sv` - Re-wired every sub-module to its actual
  port list / parameter names. The previous draft used invented interfaces
  (reg_write_en/reg_read_en, data_in/data_out, inputs_A/inputs_B/result/done,
  in_vector/out_vector, query_hv/ref_hv/hamming_dist, DIM) that matched no real
  module, producing 43 PINMISSING warnings. Accumulator width now matches
  systolic_array_param (2*DATA_WIDTH + $clog2(ROWS*COLS) + 1).
- `sim/Makefile` - Fixed broken build (command lines used spaces instead of
  tabs), added `-Wno-fatal` (Verilator promotes every warning to an error by
  default), and linked the Verilator binary from objdir to the expected
  `build/` path.
- `sw/occp_bridge.h` - Added `_DEFAULT_SOURCE` define to silence the `usleep`
  implicit-declaration warning.
- `tb/tb_matrix_multiply_2x2.sv` - Fixed a stimulus race (`en=0` was applied on
  the same posedge the DUT sampled, so the DUT never saw `en=1`); added `#1`
  after posedge. Corrected Test 3 expected values from (-19,22,-43,50) to the
  true result (9,-10,13,-14). Now 5/5 PASS.
- `tb/tb_axi4_lite_core_ctrl.sv` - Rewrote axi_write/axi_read: the old
  `wait(AWREADY && WREADY)` hung forever because the FSM asserts AWREADY in
  WRITE_ADDR and WREADY in WRITE_DATA (separate states). RDATA is now captured
  while RVALID is high. STEP 4 (timeout test) now reads the status register
  while AWVALID is held (aw_timeout is combinational and clears when AWVALID is
  released).

## How to apply
Extract inside your `open-cognitive-core` clone, then:

```bash
git checkout -b 260826-fix-rtl-integration-and-sim
git add rtl/top/open_cognitive_top.sv sim/Makefile sw/occp_bridge.h \
        tb/tb_axi4_lite_core_ctrl.sv tb/tb_matrix_multiply_2x2.sv
git commit -m "fix(rtl): correct top-level integration and simulation infrastructure"
git push -u origin 260826-fix-rtl-integration-and-sim \
  -o merge_request.create \
  -o merge_request.title="fix(rtl): correct top-level integration and simulation infrastructure" \
  -o merge_request.description="Re-wire open_cognitive_top to real module interfaces, fix sim Makefile, usleep warning, and both testbench timing/expected-value bugs"
```

## Verification (with Verilator 5.006)
- `make TOP_MODULE=tb_matrix_multiply_2x2` -> builds; run -> 5/5 PASS
- `make clean && make TOP_MODULE=tb_axi4_lite_core_ctrl` -> builds; run ->
  all 5 AXI steps correct (write 0x3, read 0x3, status 0x1, timeout 0x3,
  invalid address 0x0)
- `verilator --cc --top-module open_cognitive_top` -> elaborates with no errors
